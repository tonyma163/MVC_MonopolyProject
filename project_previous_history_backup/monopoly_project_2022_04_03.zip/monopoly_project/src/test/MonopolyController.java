/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

/**
 *
 * @author Ma Man To Tony
 */
public class MonopolyController {
    
    private MonopolyView view;
    private MonopolyModel model;
    
    public void setView(MonopolyView v) {
        this.view = v;        
    }
    
    public void setModel(MonopolyModel m) {
        this.model = m;        
    }
    
}
